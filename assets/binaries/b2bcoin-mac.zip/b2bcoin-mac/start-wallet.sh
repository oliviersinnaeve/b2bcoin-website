nohup binaries/b2bcoind --config-file configs/b2bcoin.conf &
binaries/simplewallet --config-file configs/b2bcoin.conf

