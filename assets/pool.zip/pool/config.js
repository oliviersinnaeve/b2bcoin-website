var prod = true;

var api = "http://pool.b2bcoin.ml:8117";

var api_blockexplorer = "http://pool.b2bcoin.ml:39156";

var poolHost = "pool.b2bcoin.ml";

var irc = "irc.freenode.net/#b2bcoin";

var email = "http://b2bcoin.ml/#footer";

var cryptonatorWidget = ["{symbol}-BTC", "{symbol}-USD", "{symbol}-EUR"];

var easyminerDownload = "http://b2bcoin.ml/binaries/cryptonote-easy-miner.zip";

var blockchainExplorer = "http://chainradar.com/{symbol}/block/{id}";

var transactionExplorer = "http://chainradar.com/{symbol}/transaction/{id}";

var themeCss = "themes/default-theme.css";

var networkStat = {
    "b2b": [
        ["b2bcoin.xyz", "http://pool.b2bcoin.ml:8117"],
        ["kiramine.com", "http://85.214.35.201:6117"],
        ["e-scavo.net.ar", "http://b2b.pools.e-scavo.net.ar:9987"]
    ]
};
